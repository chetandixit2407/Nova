# Release notes

## 7.3.0 — released

- **New: hide the notch with a double-click.** Double-click an empty spot in the open notch or pill and it shrinks to a slim line at the edge of the screen, out of your way. Double-click the line to bring it back. Notifications still show while it is a line.
- **Show desktop no longer hides the notch.** Pressing Show desktop (Win+D or the corner of the taskbar) used to minimize the notch until Smart Notch was opened again.
- **Left and right positions scroll again.** With the notch on the left or right, the main page is scrollable, so nothing at the bottom is cut off.
- **No more blinking download icon for old downloads.** Unfinished browser downloads left in your Downloads folder no longer count as downloading. Paused downloads show again once they resume.
- **Cleaner Settings window.** The faint square around the Settings window is gone.
- **Fewer false crash prompts.** Signing out, shutting down, or Microsoft Store updating Smart Notch in the background no longer leads to a "closed unexpectedly" prompt.

Available now through [Microsoft Store](https://apps.microsoft.com/detail/9N1D46F5X565). Update availability can vary by device and market.

## 7.2.9 — released

- **New for Pro: Phone link.** Send files between your phone and PC over Wi-Fi. Open the Drop Shelf, scan the QR code with your phone and share files both ways. No app or account needed.
- **No interruptions while you use the notch.** Files sent from your phone go straight to the Drop Shelf without replacing what you are looking at.
- **No crash prompt after signing out.** Signing out or shutting down Windows no longer leads to a crash report prompt the next time Smart Notch starts.

Available through [Microsoft Store](https://apps.microsoft.com/detail/9N1D46F5X565). Update availability can vary by device and market.

## 7.2.8 — released

- **Volume pop-up shows the right device.** On some laptops, changing the volume said the sound was playing on a connected phone or another Bluetooth device when it was coming from the speakers. It now shows a device name only when the sound really plays through it.
- **The notch comes back by itself.** If a monitor is unplugged, the PC wakes from sleep or Windows starts without a screen ready, Smart Notch waits and shows the notch again as soon as a screen is available.
- **Recovers instead of closing.** If the notch stops responding, it now recovers on its own.
- **Tidier startup.** Old startup entries left behind by earlier versions are cleaned up. If an older copy of Smart Notch (installed outside Microsoft Store) still starts with Windows, you get a one-time tip to turn it off in Startup apps.
- **Gentler background helpers.** Helpers restart more gently after a problem and stay stopped when you quit.
- **Better crash reports.** Reports explain more about what happened, so problems get fixed faster. Nothing is sent unless you press Send.
- **Join the community.** A **Join our Discord** link now sits in the Settings sidebar.

Available through [Microsoft Store](https://apps.microsoft.com/detail/9N1D46F5X565). Update availability can vary by device and market.

## 7.2.7 — released

- **See your update happen.** Pressing **Update** now opens a window that shows the download and install progress, instead of just "Updating…".
- **Smart Notch reopens after updating.** When the update finishes, Smart Notch restarts by itself instead of staying closed. (This works from the next update onwards.)
- **No crash prompt after an update.** Being closed to install an update no longer counts as an unexpected exit.
- **Join the community.** Settings → About has a new **Join Discord** button: get updates first, see what's coming next, report bugs and suggest features.
- **Cleaner notification pop-ups.** Notifications from other apps now show in a tidier card with a coloured app badge, the text centred and a quieter close button.

Available through [Microsoft Store](https://apps.microsoft.com/detail/9N1D46F5X565). Update availability can vary by device and market.

## 7.2.6 — released

- **Notch shows up after you open the lid.** If Smart Notch started while no screen was available (for example with a laptop lid closed), it could give up after a few minutes and keep running with no notch. It now waits and shows the notch as soon as a screen is available.
- **Graphics stay fast.** When Windows shut down, Smart Notch could mistake it for graphics-driver crashes and switch itself to slower software rendering. That no longer happens.
- **Fewer false crash prompts.** If your PC restarted, ran out of battery or was turned off while asleep, Smart Notch no longer says it "closed unexpectedly" and asks you to send a report.

Available through [Microsoft Store](https://apps.microsoft.com/detail/9N1D46F5X565). Update availability can vary by device and market.

## 7.2.5 — released

- **No more crash when Windows closes Smart Notch.** When Windows closed Smart Notch to install an update, restart or shut down, it could crash on the way out and Windows reported an error. It now exits cleanly.
- **Sound output list stays current.** Plugging in or removing headphones, speakers or a Bluetooth headset now updates the sound output switcher right away, instead of only after reopening the notch.
- **Smoother wake from sleep.** Smart Notch restarts its media and system helpers once after the PC wakes, instead of twice, and its single-copy check no longer pauses the app.
- **Updated app engine** (Electron 41.10.7) with the latest stability and security fixes.

Available through [Microsoft Store](https://apps.microsoft.com/detail/9N1D46F5X565). Update availability can vary by device and market.

## 7.2.4 — released

- **Crash reports you can send.** If Smart Notch closes unexpectedly, the notch offers once to send a report (Smart Notch's log and which part failed, with personal paths removed). Nothing is sent unless you press **Send**, and it asks at most once every few days.
- **Update from the app.** Settings → About → **Update** now installs the new version through Microsoft Store's own update window, right over Smart Notch. If the Store hasn't offered the update to your PC yet (it can take up to a day to reach everyone), Smart Notch opens your Store Library, where **Get updates** fetches it.
- **Clipboard (free version):** delete any item, or clear them all.
- **Bluetooth:** a headset that is connected but isn't your current sound output showed as "Not connected", and pressing Connect reported an error. It now shows as connected, with its battery level.
- **Open at sign-in:** if Smart Notch's startup was switched off while the setting is on, Smart Notch turns it back on. When Windows' own Startup apps list has Smart Notch turned off, Settings says so and opens that list for you.
- **Left and right notch:** expanded panels grow to fit what they show (Drop Shelf, Weather, Focus timer tasks and more) instead of scrolling. Clicking the to-do, Notchy or the Drop Shelf count on the closed notch now opens that view instead of Home.

Available through [Microsoft Store](https://apps.microsoft.com/detail/9N1D46F5X565). Update availability can vary by device and market.

## 7.2.3 — released

- **Permission buttons stay visible on side notches.** Left and right notch permission cards grow to fit their contents and expanded command details, keeping Allow and Always visible without adding scrolling.
- **Your background in Agent usage.** The Agent usage section now displays your selected background effect and custom wallpaper.

Available through [Microsoft Store](https://apps.microsoft.com/detail/9N1D46F5X565).

## 7.2.2 — released

- **Weather that works everywhere, and a forecast.** Smart Notch now fetches the weather itself (Open-Meteo, with wttr.in as a backup), so it no longer depends on the Windows Weather app, and it refreshes through the day instead of once at start-up. It finds your approximate city from your internet connection, or you can pick a city and °C/°F in Settings → Widgets → Weather. A new **Weather** tab shows the next 24 hours and the next 7 days (high, low, chance of rain, sunset); click the temperature to open it. Turn the tab off with *Weather forecast* in Settings → Widgets.
- **Left and right notch fixes.** The closed notch now shows the CPU, memory or battery percentage under its ring (it showed only the ring before). System stats and Agent usage are tall enough that nothing is cut off at the bottom, and the CPU/memory reading no longer overlaps the clock on a narrow pill.
- **Closed notch, your way.** A new *Closed notch* section in Settings → General gathers everything the closed notch can show. The left side can now show your **current to-do**, the next unfinished Focus timer task: tick it off right there, or click it to open the task list. **AI agent activity (Pro)** can show Notchy alone or Notchy plus what the agent is doing right now ("Editing App.jsx", "Thinking…", "Waiting for you") in place of the clock. You can also switch off the **music visualizer**, the **Drop Shelf count**, the **downloads arrow** and the **charging and low battery alerts**, and set the left side to nothing to hide the battery ring.
- **Focus timer on a side notch.** With the notch on the left or right edge, the task list was pushed out of sight. The timer is now more compact, the focus and break lengths fold into a small button next to Focus/Break, and the task list gets the rest of the space and scrolls.
- **Pro notch size stays put.** A custom notch length or thickness is now kept while the notch sits idle; before, it shrank back to the default size after a few seconds, so the setting seemed not to be remembered.
- **Fewer approval cards (Pro).** Settings → Notchy → *Approval requests in the notch* lets you choose All agents, Claude Code only, or None. Agents that run without asking (for example Claude Code in bypass mode) no longer open a card at every step; questions for you still show.
- **Fewer "not responding" reports around sleep.** While the PC goes to sleep, sleeps, wakes or is locked, Smart Notch pauses its timed window checks, so Windows no longer finds it unresponsive when it freezes apps for sleep.

Available through Microsoft Store.

## 7.2.1 — released

The first update since 7.1.12 (7.1.13 and 7.2.0 were not released; their changes are included here).

- **System stats in one place.** CPU, memory, network, storage, battery and uptime now share a single System stats view (the separate Network page is gone). Each tile shows the live number with a small graph or bar, and turns red when usage is very high. Choose exactly which tiles appear in Settings → Widgets → System stats; your choice also applies to the dashboard and Bar mode.
- **Better on desktop PCs.** PCs without a battery no longer show a permanent "100%, charging" ring. The closed notch's left side is now yours to choose in Settings → General → Collapsed indicator: Auto (battery on laptops, CPU on desktops), Battery, CPU usage, Memory usage or nothing.
- **Focus timer, redesigned.** A bigger timer with a progress bar, larger tasks and checkboxes, and a done count. Drag tasks by their handle to reorder them, sort them (unfinished first, A→Z, newest or oldest) or clear completed ones. The notch now stays open while you add tasks, so you can type several in a row.
- **Lyrics.** Lines glide smoothly from one to the next instead of jumping or flickering, and long lines in fullscreen no longer lose their last letters.
- **Fixed:** the green camera dot staying on after the camera was closed (some webcams stay powered even when idle), and the camera or microphone dot getting stuck after an app crashed while using it.
- **Shake to cloak (Pro)** now only reacts when you shake the pointer over the notch, pill or bar. Shaking it anywhere else on the screen no longer turns the Invisibility Cloak on.
- **Fewer "not responding" reports:** Smart Notch now closes promptly when Windows updates it, signs you out or shuts down, instead of waiting to be forced closed.
- **Rate Smart Notch.** Settings → About has a Rate button that opens the Microsoft Store's own rating window right over the app. After a while, the notch may also ask once (never during a call), with a "Don't ask again" option.
- **Settings:** new dark dropdown menus in place of Windows' grey lists, and a look at Tidy Shelf, the developer's new app for decluttering Downloads and Desktop.
- **Notchy follows your AI agents on its own (Pro).** Smart Notch now reads the session files Claude Code, Codex and Antigravity write as they work, so Notchy shows what each one is doing without installing anything in them: every step ("Reading App.jsx", "Running npm test"), every file edit with its added and removed lines (click it to see the changes), and a card with the agent's answer when it finishes. It works for sessions that were already open, and it can never block or slow down an agent.
- **Answer Claude Code from the notch.** Its questions show their choices right in the card (click one, or press 1–8); permission requests have Allow, Deny and Always (Claude Code's own "don't ask again" rule). Codex permission requests work too, after you trust Smart Notch's hooks once in Codex (`/hooks`). Cards now wait up to about two minutes for you instead of 30 seconds, and **Open terminal** brings the agent's window to the front.
- **Fixed for Notchy:** agent notifications not arriving when the Store app and another copy of Smart Notch were both installed (each rewrote the agents' settings for itself); Antigravity tools being blocked by a Smart Notch hook ("…SmartNotch.Native.exe is not recognized"), Antigravity no longer uses hooks at all; and Codex's notify setting calling Smart Notch in a loop. Notchy now shows how each agent is connected, and tells you when an agent's hooks are installed but not running.
- **Notchy** hops when a task finishes, shows a "?" when it has a question for you, and dozes after two quiet minutes.

Available through [Microsoft Store](https://apps.microsoft.com/detail/9N1D46F5X565). Update availability can vary by device and market.

## 7.1.12 — released

- **New (Pro): Edge Light.** One tap on the dashboard (next to Customize in Quick Launch) puts a bright band around your screen to light your face on video calls, like the Mac's Edge Light. The top row with window buttons and the taskbar stay clear, the band ignores clicks, and the screen goes to full brightness while it's on (back to normal after). Adjust its width and its warmth, from cool blue through white to warm yellow, with the arrow next to the button. Settings → Widgets → Edge Light hides the button.
- **One notch only:** fixed two notches appearing at the same time, most often after waking the PC from sleep (Windows could start a second copy while the first was still waking up). A second copy now closes itself within seconds, and a copy that has frozen is replaced automatically. This also fixes "Cloak hotkey unavailable" when the second copy held Ctrl+Alt+H.
- **Invisibility Cloak:** shaking the pointer now only turns the cloak on. It clears only with a click, Esc or Ctrl+Alt+H, so moving the pointer over the notch (for example after Ctrl+Alt+Del) can no longer uncover the screen.
- **Hide until hovered:** the notch and pill now finish closing and then slide out of view, the reverse of how they appear, instead of vanishing at once.
- **Opens on more PCs:** fixed "This app can't be opened" on some Windows 10 PCs (for example Windows 10 IoT Enterprise LTSC 2021). Windows blocked the Vulkan graphics file `vulkan-1.dll` and then marked the whole app as damaged; Smart Notch draws with Direct3D and no longer includes or loads Vulkan.
- **Fewer freezes and crashes:** the crash-reporting helper process, which Windows was reporting as frozen, is gone, and the software graphics fallback (SwiftShader) that crashed on some PCs is no longer used.
- **Custom wallpaper:** choose whether it shows only when the notch is open or on the closed notch too (Settings → Appearance → Custom wallpaper). Wallpapers and background effects now also fill the two small curved corners where the notch meets the top of the screen, instead of leaving them black.
- **Polish:** the new Smart Notch icon in the taskbar, tray and Settings; no faint band left at the top of the screen when "hide until hovered" hides the notch; and changing a setting from inside the open notch no longer freezes it.
- **Full-screen detection:** the notch no longer disappears behind ChatGPT, Discord, VS Code and other maximized apps when the taskbar is set to auto-hide. It still hides for real full-screen games, videos and F11 browsers.

Available through [Microsoft Store](https://apps.microsoft.com/detail/9N1D46F5X565). Update availability can vary by device and market.

## 7.1.11 — released

- **Shake to cloak (Pro):** shaking the pointer over the notch now toggles the Invisibility Cloak right away and every time, on every mouse and touchpad. Previously it could react late or not at all on high-precision touchpads and gaming mice, at display scaling above 100%, or when the shake swung past the edge of the notch.

## 7.1.10 — released

- **Games and full-screen apps:** Smart Notch now hides itself while a full-screen game, video or presentation covers its screen, and no longer pops open in the middle of a game. It comes back when you leave, without taking focus.
- **Always opens:** opening Smart Notch while it is already running now shows the notch and Settings instead of appearing to do nothing. If a previous copy froze, it is replaced automatically instead of blocking every launch until a restart. A start-up problem in one feature can no longer prevent the notch and tray icon from appearing.
- **Fewer freezes:** copying from busy apps (for example a large Excel selection), switching to a window that is not responding, and files on offline network shares, OneDrive online-only files or sleeping USB drives can no longer freeze Smart Notch.
- **Graphics stability:** if the graphics driver crashes repeatedly, Smart Notch starts in a safe software-rendering mode for a few days instead of closing.
- **Troubleshooting:** Settings → About → Troubleshooting now opens the real log and crash-dump folders (previously Windows reported "Location is not available").
- Fixed dragging files out of the Drop Shelf, the blank tray icon, and a downloads folder from the developer's PC being checked on every computer.

## 7.1.9 — released

- **New (Pro): Invisibility Cloak.** Off by default — turn it on in Settings → Widgets. Then press Ctrl+Alt+H (or, with Shake to cloak enabled, shake the pointer left and right inside the open notch) to frost every window behind a privacy blur. Press Ctrl+Alt+H again, click anywhere or press Esc to clear it.
- Midnight Liquid now uses the same dark molten-liquid effect as the Smart Notch website and fills the whole notch.
- Compact Pro dashboard: cards sit closer together, nothing scrolls and the notch is smaller.
- Fullscreen music: click the cover to flip it and see which app is playing; the Visualizer button cycles Waves, Bars, Ring, Mirror and Particles.
- Synced lyrics follow the song smoothly and switch lines on time, using less processor time.
- The side-notch dashboard fits completely, with a compact Quick Launch icon row.
- Open at sign-in works reliably and your choice is kept; if Windows has Smart Notch disabled in Startup apps, the app explains how to turn it back on.
- Notchy agent notifications: each agent has its own Notchy colour (Claude orange, Antigravity/Gemini blue, Codex green, Cursor indigo, Git pink), and hooks are re-connected automatically after updates.
- Bars adapt to their size: shrinking a bar hides secondary details instead of cutting features off.
- Stability: unexpected errors no longer close Smart Notch, a frozen notch recovers automatically, memory is kept in check and start-up at sign-in is lighter.
- Bar and Pill: closed notifications no longer leave an invisible area that blocks clicks under the notch, auto-hide bars no longer stay hidden, the side-bar clipboard opens beside the bar instead of over it, and damaged layout settings recover automatically.
- Fixed clipped media text in the Pro dashboard and dragging Shelf files to folders, the desktop and other apps.
- Agent completion notifications dismiss automatically; approval requests still require a response.
- Added Settings → About → Troubleshooting shortcuts to local logs and crash dumps, without automatic uploads.

Available through Microsoft Store. Update availability can vary by device and market.

## 7.1.8 — released

- Replaced background PowerShell hardware helpers with native Windows operations.
- Improved download monitoring, clipboard handling and background worker recovery.
- Improved window cleanup and positioning when display settings change.
- Added local crash and responsiveness diagnostics to help investigate failures.
- Fixed clipped text in notification cards.

Available through Microsoft Store. Update availability can vary by device and market.

## 7.1.7 — released

- Improved window-preview responsiveness and fixed a desktop-handle leak.
- Fixed enlarged side-notch panels extending beyond the screen.
- Fullscreen music centers artwork and controls when synced lyrics are unavailable.
- Added a 12-hour / 24-hour clock choice below Style in General settings.
- Improved update detection and clearer update-check messages.
- Floating pill layout with configurable distance from the screen edge.

Available through Microsoft Store. Update availability can vary by device and market.

## 7.1.6 — released

- Added Microsoft Store account ownership checks when the local Pro add-on license is missing, including for externally redeemed promo codes.
- Restore purchases now starts a fresh check after any in-progress request and retries briefly for delayed ownership updates.
- Checkout rechecks ownership after successful or already-owned results; a checkout result alone does not unlock Pro.

After updating, select **Restore purchases** using the Microsoft Store account that redeemed the Pro code.

## 7.1.5 — prepared for Store submission

- Roomier side-notch panels with larger, two-row navigation.
- Fixed clipping of music controls, including audio output and fullscreen.
- Dedicated lyrics area when the notch is on either side.
- Improved taskbar hiding for Settings and fullscreen music transitions.
- Removed the automatic copied-link popup; clipboard history remains available.
- Updated privacy disclosures for clipboard monitoring, download records and agent integrations.

The package is prepared; public Store availability is not yet confirmed. Pill mode is not part of this release.

## 7.1.0–7.1.4 — Pro rollout preparation

- One-time Microsoft Store Pro purchase and restore integration.
- Notchy, desktop screens and agent integrations.
- Free/Pro dashboard and clipboard refinements.
- Notch/bar layout fixes and audio-resource cleanup.

Subsequent builds corrected Store checkout integration and improved the Pro purchase interface and licensing notices. Free acquisition, restoration and Pro features were tested through a private Store flight. This does not confirm availability in every market or constitute a paid-charge test.

## Earlier versions

See the Microsoft Store listing for the version currently offered to your device. The public update feed advertises the latest released version.
